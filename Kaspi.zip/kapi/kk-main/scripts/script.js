document.getElementById("update-button").addEventListener("click", () => {
    alert("Список документов обновлен!");
});
